from .cpfValidator import cpfValidator as cpfIsValid
from .cnpjValidator import cnpjValidator as cnpjIsValid
from .getOnlyEmail import getOnlyEmail
from .isEmail import isEmail
from .identifyFlagCard import identifyFlagCard
from .isCreditCardValid import isCreditCardValid
from .passwordStrengthTester import passwordStrengthTester
from .validateBRPhoneNumber import validateBRPhoneNumber
